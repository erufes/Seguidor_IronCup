These screenshots were taken on Ubuntu 16.04, with the straight apt-get install of kicad.
