# kicad_ArduinoNano
Arduino Nano libraries for Arduino Nano

In a nutshell: I was working on a small project using an Arduino Nano, and couldn't find a decent Arduino nano library / module for kicad.

So here's my shot at it.  Tested with the standard version packaged for Ubuntu 16.04 and a current download on the Mac.

I assume it will also work on the windows version, it's all the same right? :-)

# Usage
* Stick the .kicad_mod  and .lib file in a libraries directory in your project or somewhere else.
* Add the library (or folder) via the schematic library manager, and PCB library manager.
* Enjoy

# Feedback and abuse

This has worked well for a couple of projects but i don't claim it's perfect.  Feel free to fork/and pull changes, or flick me an email to chris@trash.co.nz if you find something wrong with it.
